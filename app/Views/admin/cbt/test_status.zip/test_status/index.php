<?= $this->extend('layouts/app') ?>
<?= $this->section('content') ?>

<div class="container-fluid">
  <!-- Header -->
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div>
      <h4 class="mb-0"><i class="bi bi-calendar-check"></i> Pengaturan Ujian</h4>
      <small class="text-muted">Kelola jadwal, token, dan status ujian siswa.</small>
    </div>
    <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalAddTest">
      <i class="bi bi-plus-circle"></i> Tambah Jadwal
    </button>
  </div>

  <!-- Table -->
  <div class="card shadow-sm">
    <div class="card-body table-responsive">
      <table id="tableTests" class="table table-striped align-middle w-100">
        <thead class="table-light">
          <tr>
            <th width="5%">No</th>
            <th>Bank Soal</th>
            <th>Mapel</th>
            <th>Jenis Ujian</th>
            <th>Kelas</th>
            <th>Waktu Mulai</th>
            <th>Waktu Selesai</th>
            <th>Durasi</th>
            <th>Status</th>
            <th width="18%">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($testStatuses as $i => $test): ?>
            <?php
              $classList = json_decode($test['class_codes'] ?? '[]', true);
              $classNames = is_array($classList) ? implode(', ', $classList) : '-';
              $status = $test['status_label'] ?? '<span class="badge bg-secondary">Tidak Diketahui</span>';
              $visibility = $test['is_visible'] ? '<i class="bi bi-eye text-success" title="Tampil di siswa"></i>' : '<i class="bi bi-eye-slash text-danger" title="Tersembunyi"></i>';
            ?>
            <tr>
              <td><?= $i + 1 ?></td>
              <td><strong><?= esc($test['bank_code']) ?></strong></td>
              <td><?= esc($test['subject_name'] ?? '-') ?></td>
              <td><?= esc($test['exam_name'] ?? '-') ?></td>
              <td><?= esc($classNames) ?></td>
              <td><?= date('d/m/Y H:i', strtotime($test['start_time'])) ?></td>
              <td><?= date('d/m/Y H:i', strtotime($test['end_time'])) ?></td>
              <td><?= esc($test['duration']) ?> menit</td>
              <td><?= $status ?></td>
              <td>
                <div class="btn-group">
                  <button class="btn btn-outline-primary btn-sm btn-detail" data-id="<?= $test['id'] ?>">
                    <i class="bi bi-info-circle"></i>
                  </button>
                  <button class="btn btn-outline-warning btn-sm btn-edit" data-id="<?= $test['id'] ?>">
                    <i class="bi bi-pencil"></i>
                  </button>
                  <a href="<?= site_url('admin/cbt/teststatus/togglePause/' . $test['id']) ?>" class="btn btn-outline-secondary btn-sm" title="Jeda / Lanjut">
                    <i class="bi bi-pause-fill"></i>
                  </a>
                  <a href="<?= site_url('admin/cbt/teststatus/toggleVisible/' . $test['id']) ?>" class="btn btn-outline-info btn-sm" title="Tampilkan / Sembunyikan">
                    <?= $visibility ?>
                  </a>
                  <button class="btn btn-outline-danger btn-sm btn-delete" data-id="<?= $test['id'] ?>">
                    <i class="bi bi-trash"></i>
                  </button>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- ==========================================================
     MODAL: TAMBAH JADWAL UJIAN (UPDATED)
========================================================== -->
<div class="modal fade" id="modalAddTest" tabindex="-1">
  <div class="modal-dialog modal-xl modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title"><i class="bi bi-plus-circle"></i> Tambah Jadwal Ujian</h5>
        <button class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <form id="formAddTest">
          <?= csrf_field() ?>
          <div class="row">
            <!-- BANK SOAL -->
            <div class="col-md-6 mb-3">
              <label class="form-label">Bank Soal <span class="text-danger">*</span></label>
              <select name="bank_id" id="bankSelect" class="form-select" required>
                <option value="">-- Pilih Bank Soal Aktif --</option>
                <?php foreach ($banks as $b): ?>
                  <option value="<?= $b['id'] ?>"
                    data-total-pg="<?= $b['total_pg'] ?>"
                    data-total-esai="<?= $b['total_esai'] ?>">
                    <?= esc($b['code']) ?> — <?= esc($b['subject_name'] ?? '-') ?> (<?= esc($b['level']) ?>)
                  </option>
                <?php endforeach; ?>
              </select>
            </div>

            <!-- JENIS UJIAN -->
            <div class="col-md-6 mb-3">
              <label class="form-label">Jenis Ujian <span class="text-danger">*</span></label>
              <select name="exam_name_id" class="form-select" required>
                <option value="">-- Pilih Jenis Ujian --</option>
                <?php foreach ($examNames as $e): ?>
                  <option value="<?= $e['id'] ?>"><?= esc($e['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <!-- KELAS PESERTA -->
            <div class="col-md-6 mb-3">
              <label class="form-label">Kelas Peserta</label>
              <select name="class_codes[]" class="form-select select2" multiple style="width:100%;">
                <?php foreach ($classes as $c): ?>
                  <option value="<?= $c['name'] ?>"><?= esc($c['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <!-- SEMESTER -->
            <div class="col-md-3 mb-3">
              <label class="form-label">Semester</label>
              <select name="semester" class="form-select">
                <option value="ganjil">Ganjil</option>
                <option value="genap">Genap</option>
              </select>
            </div>

            <!-- JENIS MAPEL -->
            <div class="col-md-3 mb-3">
              <label class="form-label">Jenis Mapel</label>
              <select name="subject_type" id="subjectType" class="form-select">
                <option value="umum">Umum</option>
                <option value="agama">Pilihan Agama</option>
              </select>
            </div>

            <!-- AGAMA PILIHAN -->
            <div class="col-md-3 mb-3 d-none" id="agamaWrapper">
              <label class="form-label">Agama</label>
              <select name="subject_religion" class="form-select">
                <option value="">-- Pilih Agama --</option>
                <option value="Islam">Islam</option>
                <option value="Kristen">Kristen</option>
                <option value="Katolik">Katolik</option>
                <option value="Hindu">Hindu</option>
                <option value="Budha">Budha</option>
                <option value="Konghucu">Konghucu</option>
              </select>
            </div>

            <!-- JUMLAH SOAL -->
            <div class="col-md-6 mb-3">
              <label class="form-label">Jumlah Soal PG</label>
              <input type="number" name="show_pg_count" id="pgCount" class="form-control" placeholder="0">
              <small class="text-muted" id="pgInfo"></small>
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label">Jumlah Soal Esai</label>
              <input type="number" name="show_esai_count" id="esaiCount" class="form-control" placeholder="0">
              <small class="text-muted" id="esaiInfo"></small>
            </div>

            <!-- BOBOT -->
            <div class="col-md-6 mb-3">
              <label class="form-label">Bobot PG (%)</label>
              <input type="number" name="bobot_pg" id="bobotPg" class="form-control" value="50" min="0" max="100">
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label">Bobot Esai (%)</label>
              <input type="number" name="bobot_esai" id="bobotEsai" class="form-control" value="50" readonly>
            </div>

            <!-- PENGATURAN LAIN -->
            <div class="col-md-3 mb-3">
              <label class="form-label">Acak Soal</label>
              <select name="shuffle_question" class="form-select">
                <option value="ya">Ya</option>
                <option value="tidak">Tidak</option>
              </select>
            </div>
            <div class="col-md-3 mb-3">
              <label class="form-label">Acak Opsi</label>
              <select name="shuffle_option" class="form-select">
                <option value="ya">Ya</option>
                <option value="tidak">Tidak</option>
              </select>
            </div>
            <div class="col-md-3 mb-3">
              <label class="form-label">Atur Tombol Selesai</label>
              <select name="finish_button_lock" class="form-select">
                <option value="0">Tidak</option>
                <option value="0.25">¼ waktu</option>
                <option value="0.5" selected>½ waktu</option>
                <option value="0.75">¾ waktu</option>
              </select>
            </div>
            <div class="col-md-3 mb-3">
              <label class="form-label">Deteksi Kecurangan</label>
              <select name="anti_cheat" class="form-select">
                <option value="tidak">Tidak</option>
                <option value="kuat">Kuat</option>
                <option value="sangat_kuat">Sangat Kuat</option>
              </select>
            </div>

            <!-- WAKTU -->
            <div class="col-md-4 mb-3">
              <label class="form-label">Waktu Mulai</label>
              <input type="datetime-local" name="start_time" class="form-control" required>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Durasi Tes (menit)</label>
              <input type="number" name="duration" class="form-control" placeholder="90" required>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Ujian Ditutup</label>
              <input type="datetime-local" name="end_time" class="form-control" required>
            </div>

            <!-- TOKEN -->
            <div class="col-md-4 mb-3">
              <label class="form-label">Tampilkan Token?</label>
              <select name="show_token" class="form-select">
                <option value="ya">Ya</option>
                <option value="tidak">Tidak</option>
              </select>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Tampilkan Nilai?</label>
              <select name="show_score" class="form-select">
                <option value="ya">Ya</option>
                <option value="tidak">Tidak</option>
              </select>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Token</label>
              <div class="input-group">
                <input type="text" name="token" id="tokenField" class="form-control" maxlength="6" placeholder="Generate otomatis">
                <button type="button" class="btn btn-outline-secondary" id="btnGenerateToken"><i class="bi bi-shuffle"></i></button>
              </div>
            </div>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
        <button id="btnSaveTest" class="btn btn-success"><i class="bi bi-save"></i> Simpan Jadwal</button>
      </div>
    </div>
  </div>
</div>

<!-- ==========================================================
     MODAL: RINCIAN UJIAN
========================================================== -->
<div class="modal fade" id="modalDetailTest" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header bg-info text-white">
        <h5 class="modal-title"><i class="bi bi-info-circle"></i> Rincian Jadwal Ujian</h5>
        <button class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div id="detailContent">
          <div class="text-center text-muted py-4">
            <i class="bi bi-hourglass-split fs-2"></i><br>
            Memuat data ujian...
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>

<!-- ==========================================================
     MODAL: EDIT JADWAL UJIAN (AJAX-READY)
========================================================== -->
<div class="modal fade" id="modalEditTest" tabindex="-1">
  <div class="modal-dialog modal-xl modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header bg-warning text-dark">
        <h5 class="modal-title"><i class="bi bi-pencil-square"></i> Edit Jadwal Ujian</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <form id="formEditTest">
          <?= csrf_field() ?>
          <input type="hidden" name="id">

          <div class="row">
            <!-- BANK SOAL -->
            <div class="col-md-6 mb-3">
              <label class="form-label">Bank Soal <span class="text-danger">*</span></label>
              <select name="bank_id" id="bankSelectEdit" class="form-select" required>
                <option value="">-- Pilih Bank Soal Aktif --</option>
                <?php foreach ($banks as $b): ?>
                  <option value="<?= $b['id'] ?>"
                    data-total-pg="<?= $b['total_pg'] ?>"
                    data-total-esai="<?= $b['total_esai'] ?>">
                    <?= esc($b['code']) ?> — <?= esc($b['subject_name'] ?? '-') ?> (<?= esc($b['level']) ?>)
                  </option>
                <?php endforeach; ?>
              </select>
            </div>

            <!-- JENIS UJIAN -->
            <div class="col-md-6 mb-3">
              <label class="form-label">Jenis Ujian <span class="text-danger">*</span></label>
              <select name="exam_name_id" class="form-select" required>
                <option value="">-- Pilih Jenis Ujian --</option>
                <?php foreach ($examNames as $e): ?>
                  <option value="<?= $e['id'] ?>"><?= esc($e['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <!-- KELAS PESERTA -->
            <div class="col-md-6 mb-3">
              <label class="form-label">Kelas Peserta</label>
              <select name="class_codes[]" class="form-select select2Edit" multiple style="width:100%;">
                <?php foreach ($classes as $c): ?>
                  <option value="<?= $c['name'] ?>"><?= esc($c['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <!-- SEMESTER -->
            <div class="col-md-3 mb-3">
              <label class="form-label">Semester</label>
              <select name="semester" class="form-select">
                <option value="ganjil">Ganjil</option>
                <option value="genap">Genap</option>
              </select>
            </div>

            <!-- JENIS MAPEL -->
            <div class="col-md-3 mb-3">
              <label class="form-label">Jenis Mapel</label>
              <select name="subject_type" id="subjectTypeEdit" class="form-select">
                <option value="umum">Umum</option>
                <option value="agama">Pilihan Agama</option>
              </select>
            </div>

            <!-- AGAMA -->
            <div class="col-md-3 mb-3 d-none" id="agamaWrapperEdit">
              <label class="form-label">Agama</label>
              <select name="religion" class="form-select">
                <option value="">-- Pilih Agama --</option>
                <?php foreach (['Islam','Kristen','Katolik','Hindu','Budha','Konghucu'] as $r): ?>
                  <option value="<?= $r ?>"><?= $r ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <!-- JUMLAH SOAL -->
            <div class="col-md-6 mb-3">
              <label class="form-label">Jumlah Soal PG</label>
              <input type="number" name="show_pg_count" id="pgCountEdit" class="form-control" placeholder="0">
              <small class="text-muted" id="pgInfoEdit"></small>
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label">Jumlah Soal Esai</label>
              <input type="number" name="show_esai_count" id="esaiCountEdit" class="form-control" placeholder="0">
              <small class="text-muted" id="esaiInfoEdit"></small>
            </div>

            <!-- BOBOT -->
            <div class="col-md-6 mb-3">
              <label class="form-label">Bobot PG (%)</label>
              <input type="number" name="bobot_pg" id="bobotPgEdit" class="form-control" min="0" max="100">
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label">Bobot Esai (%)</label>
              <input type="number" name="bobot_esai" id="bobotEsaiEdit" class="form-control" readonly>
            </div>

            <!-- PENGATURAN LAIN -->
            <div class="col-md-3 mb-3">
              <label class="form-label">Acak Soal</label>
              <select name="shuffle_question" class="form-select">
                <option value="ya">Ya</option>
                <option value="tidak">Tidak</option>
              </select>
            </div>
            <div class="col-md-3 mb-3">
              <label class="form-label">Acak Opsi</label>
              <select name="shuffle_option" class="form-select">
                <option value="ya">Ya</option>
                <option value="tidak">Tidak</option>
              </select>
            </div>
            <div class="col-md-3 mb-3">
              <label class="form-label">Atur Tombol Selesai</label>
              <select name="finish_button_lock" class="form-select">
                <option value="0">Tidak</option>
                <option value="0.25">¼ waktu</option>
                <option value="0.5">½ waktu</option>
                <option value="0.75">¾ waktu</option>
              </select>
            </div>
            <div class="col-md-3 mb-3">
              <label class="form-label">Deteksi Kecurangan</label>
              <select name="anti_cheat" class="form-select">
                <option value="tidak">Tidak</option>
                <option value="kuat">Kuat</option>
                <option value="sangat_kuat">Sangat Kuat</option>
              </select>
            </div>

            <!-- WAKTU -->
            <div class="col-md-4 mb-3">
              <label class="form-label">Waktu Mulai</label>
              <input type="datetime-local" name="start_time" class="form-control" required>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Durasi Tes (menit)</label>
              <input type="number" name="duration" class="form-control" required>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Ujian Ditutup</label>
              <input type="datetime-local" name="end_time" class="form-control" required>
            </div>

            <!-- TOKEN -->
            <div class="col-md-4 mb-3">
              <label class="form-label">Tampilkan Token?</label>
              <select name="show_token" class="form-select">
                <option value="ya">Ya</option>
                <option value="tidak">Tidak</option>
              </select>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Tampilkan Nilai?</label>
              <select name="show_score" class="form-select">
                <option value="ya">Ya</option>
                <option value="tidak">Tidak</option>
              </select>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Token</label>
              <div class="input-group">
                <input type="text" name="token" id="tokenFieldEdit" class="form-control" maxlength="6">
                <button type="button" class="btn btn-outline-secondary" id="btnGenerateTokenEdit">
                  <i class="bi bi-shuffle"></i>
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>

      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
        <button id="btnUpdateTest" class="btn btn-warning">
          <i class="bi bi-save"></i> Update Jadwal
        </button>
      </div>
    </div>
  </div>
</div>


<?= $this->endSection() ?>


<?= $this->section('scripts') ?>
<script>
$(function() {

  /* ======================================================
   * 1️⃣ Inisialisasi Select2 (lebar penuh)
   * ====================================================== */
  $('.select2').select2({
    dropdownParent: $('#modalAddTest'),
    width: '100%',
    placeholder: "Pilih kelas peserta..."
  });

  /* ======================================================
   * 2️⃣ Generate Token Acak (Tambah)
   * ====================================================== */
  $('#btnGenerateToken').on('click', function() {
    const token = Math.random().toString(36).substring(2, 8).toUpperCase();
    $('#tokenField').val(token);
  });

  /* ======================================================
   * 3️⃣ Tampilkan / Sembunyikan Pilihan Agama (Tambah)
   * ====================================================== */
  $('#subjectType').on('change', function() {
    if ($(this).val() === 'agama') {
      $('#agamaWrapper').removeClass('d-none');
    } else {
      $('#agamaWrapper').addClass('d-none');
    }
  });

  /* ======================================================
   * 4️⃣ Saat Pilih Bank Soal → tampilkan total PG & Esai (Tambah)
   * ====================================================== */
  $('#bankSelect').on('change', function() {
    const totalPg = $(this).find(':selected').data('total-pg') || 0;
    const totalEsai = $(this).find(':selected').data('total-esai') || 0;
    $('#pgInfo').text(`Tersedia ${totalPg} soal Pilihan Ganda`);
    $('#esaiInfo').text(`Tersedia ${totalEsai} soal Esai`);
    $('#pgCount').attr('max', totalPg);
    $('#esaiCount').attr('max', totalEsai);
  });

  /* ======================================================
   * 5️⃣ Validasi Jumlah Soal PG & Esai (Tambah)
   * ====================================================== */
  $('#pgCount, #esaiCount').on('input', function() {
    const max = parseInt($(this).attr('max') || 0);
    const val = parseInt($(this).val() || 0);
    if (val > max && max > 0) {
      Swal.fire('Jumlah Soal Melebihi Batas',
        'Jumlah soal yang dimasukkan melebihi total soal di bank soal!',
        'warning'
      );
      $(this).val(max);
    }
  });

  /* ======================================================
   * 6️⃣ Otomatis Hubungkan Bobot PG & Esai (Tambah)
   * ====================================================== */
  $('#bobotPg').on('input', function() {
    let pg = parseInt($(this).val()) || 0;
    if (pg > 100) pg = 100;
    if (pg < 0) pg = 0;
    $('#bobotPg').val(pg);
    $('#bobotEsai').val(100 - pg);
  });

  /* ======================================================
   * 7️⃣ Tombol Simpan Jadwal (Tambah via AJAX)
   * ====================================================== */
  $('#btnSaveTest').on('click', function() {
    const form = $('#formAddTest');
    $.ajax({
      url: "<?= site_url('admin/cbt/teststatus/store') ?>",
      type: "POST",
      data: form.serialize(),
      dataType: "json",
      beforeSend: () => {
        $('#btnSaveTest')
          .prop('disabled', true)
          .html('<i class="bi bi-hourglass-split"></i> Menyimpan...');
      },
      success: function(res) {
        if (res.success) {
          Swal.fire({
            icon: 'success',
            title: 'Berhasil',
            text: res.message,
            timer: 1800,
            showConfirmButton: false
          }).then(() => location.reload());
        } else {
          Swal.fire('Gagal', res.message || 'Gagal menyimpan.', 'error');
        }
      },
      error: function(xhr) {
        Swal.fire('Error', 'Terjadi kesalahan server. Periksa koneksi.', 'error');
        console.error(xhr.responseText);
      },
      complete: () => {
        $('#btnSaveTest')
          .prop('disabled', false)
          .html('<i class="bi bi-save"></i> Simpan Jadwal');
      }
    });
  });

  /* ======================================================
   * 8️⃣ Hapus Jadwal Ujian
   * ====================================================== */
  $(document).on('click', '.btn-delete', function() {
    const id = $(this).data('id');
    Swal.fire({
      title: 'Hapus Jadwal?',
      text: 'Semua data hasil ujian yang terkait juga akan terhapus!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Ya, Hapus!',
      cancelButtonText: 'Batal'
    }).then((r) => {
      if (r.isConfirmed) {
        window.location.href = "<?= site_url('admin/cbt/teststatus/delete/') ?>" + id;
      }
    });
  });

  /* ======================================================
   * 9️⃣ Detail Jadwal (AJAX)
   * ====================================================== */
  $(document).on('click', '.btn-detail', function() {
    const id = $(this).data('id');
    $('#modalDetailTest').modal('show');
    $('#detailContent').html(`<div class="text-center text-muted py-4">
      <i class="bi bi-hourglass-split fs-2"></i><br>Memuat data ujian...
    </div>`);

    $.get("<?= site_url('admin/cbt/teststatus/detail/') ?>" + id, function(res) {
      if (res.success) {
        const t = res.data;
        let kelas = Array.isArray(t.class_codes) ? t.class_codes.join(', ') : t.class_codes;
        $('#detailContent').html(`
          <table class="table table-bordered table-sm">
            <tr><th width="30%">Bank Soal</th><td>${t.bank_code || '-'}</td></tr>
            <tr><th>Mapel</th><td>${t.subject_name || '-'}</td></tr>
            <tr><th>Jenis Ujian</th><td>${t.exam_name || '-'}</td></tr>
            <tr><th>Kelas Peserta</th><td>${kelas || '-'}</td></tr>
            <tr><th>Semester</th><td>${t.semester}</td></tr>
            <tr><th>Jenis Mapel</th><td>${t.subject_type}</td></tr>
            <tr><th>Jumlah Soal PG</th><td>${t.show_pg_count}</td></tr>
            <tr><th>Jumlah Soal Esai</th><td>${t.show_esai_count}</td></tr>
            <tr><th>Bobot</th><td>PG: ${t.bobot_pg}% | Esai: ${t.bobot_esai}%</td></tr>
            <tr><th>Durasi Tes</th><td>${t.duration} menit</td></tr>
            <tr><th>Waktu Mulai</th><td>${t.start_time}</td></tr>
            <tr><th>Ujian Ditutup</th><td>${t.end_time}</td></tr>
            <tr><th>Token</th><td>${t.token || '-'}</td></tr>
            <tr><th>Tampilkan Token</th><td>${t.show_token ? 'Ya' : 'Tidak'}</td></tr>
            <tr><th>Tampilkan Nilai</th><td>${t.show_score ? 'Ya' : 'Tidak'}</td></tr>
            <tr><th>Acak Soal</th><td>${t.shuffle_question ? 'Ya' : 'Tidak'}</td></tr>
            <tr><th>Acak Opsi</th><td>${t.shuffle_option ? 'Ya' : 'Tidak'}</td></tr>
            <tr><th>Deteksi Kecurangan</th><td>${t.anti_cheat}</td></tr>
          </table>`);
      } else {
        $('#detailContent').html(`<div class="alert alert-danger">Gagal memuat data ujian.</div>`);
      }
    }, 'json');
  });


/* ======================================================
 * 🔟 Edit Jadwal Ujian (AJAX)
 * ====================================================== */
$(document).on('click', '.btn-edit', function() {
  const id = $(this).data('id');
  $('#modalEditTest').modal('show');
  $('#formEditTest')[0].reset();

  $.get("<?= site_url('admin/cbt/teststatus/edit/') ?>" + id, function(res) {
    if (res.success) {
      const t = res.data;

      $('#formEditTest input[name=id]').val(t.id);
      $('#formEditTest select[name=bank_id]').val(t.bank_id);
      $('#formEditTest select[name=exam_name_id]').val(t.exam_name_id);
      $('#formEditTest select[name=semester]').val(t.semester);
      $('#formEditTest select[name=subject_type]').val(t.subject_type).trigger('change');
      $('#formEditTest select[name=religion]').val(t.religion);
      $('#formEditTest input[name=show_pg_count]').val(t.show_pg_count);
      $('#formEditTest input[name=show_esai_count]').val(t.show_esai_count);
      $('#formEditTest input[name=bobot_pg]').val(t.bobot_pg);
      $('#formEditTest input[name=bobot_esai]').val(t.bobot_esai);
      $('#formEditTest select[name=shuffle_question]').val(t.shuffle_question);
      $('#formEditTest select[name=shuffle_option]').val(t.shuffle_option);
      $('#formEditTest select[name=finish_button_lock]').val(t.finish_button_lock);
      $('#formEditTest input[name=start_time]').val(t.start_time.replace(' ', 'T'));
      $('#formEditTest input[name=end_time]').val(t.end_time.replace(' ', 'T'));
      $('#formEditTest input[name=duration]').val(t.duration);
      $('#formEditTest select[name=show_token]').val(t.show_token);
      $('#formEditTest select[name=show_score]').val(t.show_score);
      $('#formEditTest input[name=token]').val(t.token);
      $('#formEditTest select[name=anti_cheat]').val(t.anti_cheat);

      // kelas
      const selected = JSON.parse(t.class_codes || "[]");
      $('#formEditTest select[name="class_codes[]"]').val(selected).trigger('change');
    } else {
      Swal.fire('Gagal', 'Data ujian tidak ditemukan.', 'error');
    }
  }, 'json');
});

/* ======================================================
 * 11️⃣ Update Jadwal (AJAX)
 * ====================================================== */
$('#btnUpdateTest').on('click', function() {
  const id = $('#formEditTest input[name=id]').val();
  const form = $('#formEditTest');

  $.ajax({
    url: "<?= site_url('admin/cbt/teststatus/update/') ?>" + id,
    type: "POST",
    data: form.serialize(),
    dataType: "json",
    beforeSend: () => {
      $('#btnUpdateTest').prop('disabled', true)
        .html('<i class="bi bi-hourglass-split"></i> Menyimpan...');
    },
    success: function(res) {
      if (res.success) {
        Swal.fire({
          icon: 'success',
          title: 'Berhasil',
          text: res.message,
          timer: 1800,
          showConfirmButton: false
        }).then(() => location.reload());
      } else {
        Swal.fire('Gagal', res.message || 'Gagal memperbarui jadwal.', 'error');
      }
    },
    error: function(xhr) {
      console.error('Error:', xhr.responseText);
      Swal.fire('Error', 'Terjadi kesalahan server.', 'error');
    },
    complete: () => {
      $('#btnUpdateTest').prop('disabled', false)
        .html('<i class="bi bi-save"></i> Update Jadwal');
    }
  });
});

});
</script>


<?= $this->endSection() ?>

<?= $this->extend('layouts/app') ?>
<?= $this->section('content') ?>

<div class="container-fluid">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div>
      <h4 class="mb-0">Edit Soal Bank: <?= esc($bank['code']) ?></h4>
      <small class="text-muted">
        Mata pelajaran: <?= esc($bank['subject_name'] ?? '-') ?> | Level: <?= esc($bank['level']) ?>
      </small>
    </div>
    <a href="<?= site_url('admin/cbt/banksoal/detail/' . $bank['id']) ?>" class="btn btn-outline-secondary">
      <i class="bi bi-arrow-left"></i> Kembali
    </a>
  </div>

  <div class="card shadow-sm">
    <div class="card-body">
      <form id="formEditSoal" action="<?= site_url('admin/cbt/banksoal/update_soal/' . $bank['id'] . '/' . $soal['id']) ?>" method="post">
        <?= csrf_field() ?>

        <div class="mb-3">
          <label class="form-label fw-bold">Edit Soal (lengkap beserta opsi dan gambar)</label>
          <textarea id="editor" name="raw_text"><?= esc($soal['raw_text'] ?? $soal['question_text']) ?></textarea>
        </div>

        <div class="d-flex justify-content-between align-items-center mt-3">
          <button type="button" id="btnPreview" class="btn btn-info">
            <i class="bi bi-eye"></i> Preview Parsing
          </button>
          <button type="submit" id="btnSave" class="btn btn-success">
            <i class="bi bi-save"></i> Simpan Perubahan
          </button>
        </div>
      </form>
    </div>
  </div>

  <div id="previewResult" class="mt-4"></div>
</div>

<?= $this->endSection() ?>


<?= $this->section('scripts') ?>
<!-- ✅ TinyMCE CDN -->
<script src="https://cdn.tiny.cloud/1/0uga4rg439nae4lkk1d91mvh29joy8u8nak79uj0qagdzbip/tinymce/8/tinymce.min.js"
        referrerpolicy="origin"></script>

<script>
$(function() {
  const draftKey = 'cbt_edit_soal_' + <?= $bank['id'] ?> + '_<?= $soal['id'] ?>';
  const oldContent = <?= json_encode($soal['raw_text'] ?? $soal['question_text']) ?>;

  // 🔧 Inisialisasi TinyMCE
  tinymce.init({
    selector: '#editor',
    height: 600,
    menubar: true,
    branding: false,
    plugins: 'image link lists table code paste autosave',
    toolbar: 'undo redo | styles | bold italic underline | alignleft aligncenter alignright | bullist numlist outdent indent | image link table | removeformat code',
    paste_data_images: true,
    automatic_uploads: true,
    images_upload_url: '<?= site_url("admin/cbt/banksoal/uploadImage") ?>',
    images_upload_credentials: true,
    images_reuse_filename: false,

    images_upload_handler: function (blobInfo, success, failure) {
      let formData = new FormData();
      formData.append('file', blobInfo.blob(), blobInfo.filename());

      $.ajax({
        url: '<?= site_url("admin/cbt/banksoal/uploadImage") ?>',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (res) {
          if (res.location) success(res.location);
          else failure('Upload gagal');
        },
        error: function () {
          failure('Gagal upload gambar.');
        }
      });
    },

    setup: function (editor) {
      editor.on('init', function () {
        const savedDraft = localStorage.getItem(draftKey);
        if (savedDraft && savedDraft.trim() !== '') {
          editor.setContent(savedDraft);
        } else if (oldContent && oldContent.trim() !== '') {
          editor.setContent(oldContent);
        }
      });

      editor.on('input change', function () {
        localStorage.setItem(draftKey, editor.getContent());
      });
    }
  });

  // 🔍 Preview Parsing
  $('#btnPreview').on('click', function () {
    const content = tinymce.get('editor').getContent();
    const plain = $('<div>').html(content).text().trim();

    if (!plain) return Swal.fire('Kosong', 'Silakan tempelkan soal terlebih dahulu.', 'warning');

    const blocks = plain.split(/Soal:\s*\d+\)/i).filter(b => b.trim() !== '');
    const total = blocks.length;
    const pgCount = (plain.match(/Kunci\s*[:.]?\s*[A-E]/gi) || []).length;
    const esaiCount = (plain.match(/Kunci\s*[:.]?\s*esai/gi) || []).length;

    let preview = '';
    blocks.slice(0, 3).forEach((b, i) => {
      const cut = b.length > 200 ? b.substring(0, 200) + '...' : b;
      preview += `<div class="p-2 mb-2 border rounded bg-white">
        <strong>Soal ${i + 1}:</strong> ${cut}
      </div>`;
    });

    $('#previewResult').html(`
      <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
          <i class="bi bi-eye"></i> Preview Soal
        </div>
        <div class="card-body">
          <p><strong>Total Soal:</strong> ${total} | PG: ${pgCount} | Esai: ${esaiCount}</p>
          ${preview}
        </div>
      </div>
    `);
  });

  // 💾 Simpan Perubahan
  $('#formEditSoal').on('submit', function(e) {
    e.preventDefault();

    const html = tinymce.get('editor').getContent().trim();
    if (!html) return Swal.fire('Kosong', 'Silakan tempelkan soal terlebih dahulu.', 'warning');

    $('#btnSave').prop('disabled', true).html('<i class="bi bi-hourglass-split"></i> Menyimpan...');

    const formData = new FormData(this);
    formData.set('raw_text', html);

    $.ajax({
      url: $(this).attr('action'),
      type: 'POST',
      data: formData,
      processData: false,
      contentType: false,
      success: function(res) {
        localStorage.removeItem(draftKey);
        Swal.fire('Berhasil', 'Soal berhasil diperbarui!', 'success').then(() => {
          window.location.href = "<?= site_url('admin/cbt/banksoal/detail/' . $bank['id']) ?>";
        });
      },
      error: function() {
        Swal.fire('Gagal', 'Terjadi kesalahan saat menyimpan soal.', 'error');
      },
      complete: function() {
        $('#btnSave').prop('disabled', false).html('<i class="bi bi-save"></i> Simpan Perubahan');
      }
    });
  });
});
</script>

<?= $this->endSection() ?>

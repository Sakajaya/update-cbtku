<?= $this->extend('layouts/app') ?>
<?= $this->section('content') ?>

<div class="container-fluid">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div>
      <h4 class="mb-0">Tambah Soal ke Bank: <?= esc($bank['code']) ?></h4>
      <small class="text-muted">
        Mata pelajaran: <?= esc($bank['subject_name'] ?? '-') ?> | Level: <?= esc($bank['level']) ?>
      </small>
    </div>
    <a href="<?= site_url('admin/cbt/banksoal/detail/' . $bank['id']) ?>" class="btn btn-outline-secondary">
      <i class="bi bi-arrow-left"></i> Kembali
    </a>
  </div>

  <div class="card shadow-sm">
    <div class="card-body">
      <form id="formAddSoal" method="post" action="<?= site_url('admin/cbt/banksoal/saveParsedSoal/' . $bank['id']) ?>">
        <?= csrf_field() ?>

        <div class="mb-3">
          <label class="form-label fw-bold">Paste Soal dari Word</label>
          <textarea id="editor" name="raw_text"></textarea>
          <small class="text-muted d-block mt-2">
            Format contoh:
            <pre class="bg-light p-2 rounded mt-2">
Soal:1)Warna bendera Indonesia adalah ....
A:Putih Merah
B:Merah Putih
C:Hijau Biru
D:Kuning Kelabu
Kunci:B

Soal:30)Siapakah pencipta lagu Indonesia Raya?
Kunci:esai
            </pre>
          </small>
        </div>

        <div class="d-flex justify-content-between align-items-center mt-3">
          <button type="button" id="btnPreview" class="btn btn-info">
            <i class="bi bi-eye"></i> Preview Parsing
          </button>
          <button type="submit" id="btnSave" class="btn btn-success">
            <i class="bi bi-save"></i> Simpan Semua Soal
          </button>
        </div>
      </form>
    </div>
  </div>

  <div id="previewResult" class="mt-4"></div>
</div>

<?= $this->endSection() ?>

<?= $this->section('scripts') ?>

<!-- 🔹 Load TinyMCE lokal -->
<script src="https://cdn.tiny.cloud/1/0uga4rg439nae4lkk1d91mvh29joy8u8nak79uj0qagdzbip/tinymce/8/tinymce.min.js" referrerpolicy="origin" crossorigin="anonymous"></script>
<script>
$(function() {
  const draftKey = 'cbt_soal_draft_' + <?= $bank['id'] ?>;

  tinymce.init({
    selector: 'textarea',
    height: 500,
    plugins: [
      // Core editing features
      'anchor', 'autolink', 'charmap', 'codesample', 'emoticons', 'link', 'lists', 'media', 'searchreplace', 'table', 'visualblocks', 'wordcount',
      // Your account includes a free trial of TinyMCE premium features
      // Try the most popular premium features until Oct 22, 2025:
      'checklist', 'mediaembed', 'casechange', 'formatpainter', 'pageembed', 'a11ychecker', 'tinymcespellchecker', 'permanentpen', 'powerpaste', 'advtable', 'advcode', 'advtemplate', 'ai', 'uploadcare', 'mentions', 'tinycomments', 'tableofcontents', 'footnotes', 'mergetags', 'autocorrect', 'typography', 'inlinecss', 'markdown','importword', 'exportword', 'exportpdf'
    ],
    toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography uploadcare | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat',
    tinycomments_mode: 'embedded',
    tinycomments_author: 'Author name',
    mergetags_list: [
      { value: 'First.Name', title: 'First Name' },
      { value: 'Email', title: 'Email' },
    ],
    ai_request: (request, respondWith) => respondWith.string(() => Promise.reject('See docs to implement AI Assistant')),
    uploadcare_public_key: 'caed409e1c74203dcfd1',
  });

  // 🔹 Preview parsing
  $('#btnPreview').on('click', function() {
    const html = tinymce.get('editor').getContent().trim();
    const text = $('<div>').html(html).text().trim();

    if (!text) return Swal.fire('Kosong', 'Silakan tempelkan soal terlebih dahulu.', 'warning');

    const blocks = text.split(/Soal:\s*\d+\)/i).filter(b => b.trim() !== '');
    const validBlocks = blocks.filter(b => b.trim().length > 30);
    const totalBlocks = validBlocks.length;
    const pgCount = (text.match(/Kunci\s*[:.]?\s*[A-E]/gi) || []).length;
    const esaiCount = (text.match(/Kunci\s*[:.]?\s*esai/gi) || []).length;

    let previewSoals = '';
    validBlocks.slice(0, 100).forEach((block, idx) => {
      const plainBlock = block.replace(/<[^>]*>/g, ' ').trim();
      const soalPreview = plainBlock.substring(0, 200) + (plainBlock.length > 200 ? '...' : '');
      previewSoals += `<div class="mb-2 p-2 border rounded bg-light"><strong>${idx + 1}.</strong> ${soalPreview}</div>`;
    });

    const previewHtml = `
      <div class="card shadow-sm">
        <div class="card-header bg-primary text-white"><h6 class="mb-0"><i class="bi bi-eye"></i> Preview Soal</h6></div>
        <div class="card-body">
          <p><strong>Total Soal:</strong> ${totalBlocks} | PG: ${pgCount} | Esai: ${esaiCount}</p>
          ${previewSoals}
        </div>
      </div>`;
    $('#previewResult').html(previewHtml);
  });

  // 🔹 Submit (Simpan Soal)
  $('#formAddSoal').on('submit', function(e) {
    e.preventDefault();
    const html = tinymce.get('editor').getContent().trim();
    if (!html) return Swal.fire('Kosong', 'Silakan tempelkan soal terlebih dahulu.', 'warning');

    $('#btnSave').prop('disabled', true).html('<i class="bi bi-hourglass-split"></i> Menyimpan...');

    const formData = new FormData(this);
    formData.set('raw_text', html);

    $.ajax({
      url: $(this).attr('action'),
      type: 'POST',
      data: formData,
      processData: false,
      contentType: false,
      success: function(res) {
        localStorage.removeItem(draftKey);
        Swal.fire('Berhasil', 'Soal berhasil disimpan!', 'success').then(() => {
          window.location.href = "<?= site_url('admin/cbt/banksoal/detail/' . $bank['id']) ?>";
        });
      },
      error: function(xhr) {
        Swal.fire('Gagal', 'Terjadi kesalahan saat menyimpan soal.', 'error');
      },
      complete: function() {
        $('#btnSave').prop('disabled', false).html('<i class="bi bi-save"></i> Simpan Semua Soal');
      }
    });
  });
});
</script>

<?= $this->endSection() ?>

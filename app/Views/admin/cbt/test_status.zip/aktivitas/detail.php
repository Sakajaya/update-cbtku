<?= $this->extend('layouts/app') ?>
<?= $this->section('content') ?>

<div class="container-fluid">
  <div class="card shadow-sm mb-3">
    <div class="card-body d-flex align-items-center">
      <div class="me-3">
        <div class="icon bg-light rounded-circle p-3">
          <i class="bi bi-graph-up fs-3 text-primary"></i>
        </div>
      </div>
      <div>
        <h5 class="mb-1">Aktivitas User</h5>
        <p class="mb-0 text-muted">Halaman ini menampilkan aktivitas seluruh siswa pada ujian ini.</p>
      </div>
    </div>
  </div>

  <div class="card mb-3">
    <div class="card-body d-flex justify-content-between align-items-center">
      <div>
        <strong>Kode Ujian:</strong> <?= esc($test['code']) ?> — 
        <strong><?= esc($test['subject_name']) ?></strong>
      </div>
      <div>
        <a href="<?= current_url() ?>" class="btn btn-warning btn-sm">
          <i class="bi bi-arrow-clockwise"></i>
        </a>
        <a href="<?= site_url('admin/cbt/aktivitas') ?>" class="btn btn-success btn-sm">
          <i class="bi bi-arrow-left"></i>
        </a>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <div class="mb-2">
        <button class="btn btn-primary btn-sm" id="btnBelumSelesai">
          <i class="bi bi-person-x"></i> <span id="countBelum"><?= $count_belum ?? 0 ?></span> user belum selesai
        </button>
      </div>

      <table id="tableAktivitasUser" class="table table-bordered align-middle w-100">
        <thead class="table-info text-center">
          <tr>
            <th>No</th>
            <th>Nomor Ujian</th>
            <th>Nama</th>
            <th>Waktu Mulai</th>
            <th>Soal Terjawab</th>
            <th>Sisa Waktu (Menit)</th>
            <th>Nilai</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($sessions as $i => $s): ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td><?= esc($s['id']) ?></td>
            <td><?= esc($s['student_name']) ?></td>
            <td><?= date('Y-m-d H:i:s', $s['started_at']) ?></td>
            <td class="text-center">
              <button class="btn btn-sm btn-warning btn-detail-jawaban" data-id="<?= $s['id'] ?>">
                <i class="bi bi-list"></i> Lihat
              </button>
            </td>
            <td class="text-center"><?= $s['remaining_minutes'] ?? 0 ?></td>
            <td class="text-center">
              <?= $s['status'] === 'finished' ? '<strong>'.$s['score'].'</strong>' : '<span class="badge bg-secondary">Belum Selesai</span>' ?>
            </td>
            <td class="text-center">
              <?php if ($s['status'] === 'active'): ?>
                <span class="badge bg-success">Sedang Ujian</span>
              <?php elseif ($s['status'] === 'finished'): ?>
                <span class="badge bg-primary">Selesai</span>
              <?php else: ?>
                <span class="badge bg-danger">Waktu Habis</span>
              <?php endif; ?>
            </td>
            <td class="text-center">
              <div class="btn-group">
                <?php if ($s['status'] === 'active'): ?>
                  <button class="btn btn-sm btn-primary btn-force-finish" data-id="<?= $s['id'] ?>">
                    <i class="bi bi-check2-circle"></i> Selesaikan
                  </button>
                <?php else: ?>
                  <button class="btn btn-sm btn-outline-primary" disabled>
                    <i class="bi bi-check2"></i> Selesai
                  </button>
                <?php endif; ?>
                <button class="btn btn-sm btn-warning btn-tambah-waktu" data-id="<?= $s['id'] ?>">
                  <i class="bi bi-clock-history"></i> Tambah Waktu
                </button>
                <button class="btn btn-sm btn-danger btn-reset" data-id="<?= $s['id'] ?>">
                  <i class="bi bi-arrow-counterclockwise"></i> Reset
                </button>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal detail jawaban -->
<div class="modal fade" id="modalDetailJawaban" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title">Detail Jawaban Siswa</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div id="detailContent" class="text-center text-muted">Memuat data...</div>
      </div>
    </div>
  </div>
</div>

<?= $this->endSection() ?>


<?= $this->section('scripts') ?>
<script>
$(function(){
  const table = $('#tableAktivitasUser').DataTable({
    responsive: true,
    order: [],
    pageLength: 25,
    language: {
      search: "Cari:",
      lengthMenu: "Tampilkan _MENU_ data",
      zeroRecords: "Tidak ada data ditemukan",
      info: "Menampilkan _START_ - _END_ dari _TOTAL_ data"
    }
  });

  // 🔹 Detail jawaban
  $(document).on('click', '.btn-detail-jawaban', function(){
    const id = $(this).data('id');
    $('#detailContent').html('Memuat...');
    $('#modalDetailJawaban').modal('show');
    $.get("<?= site_url('admin/cbt/aktivitas/detail_jawaban/') ?>" + id, function(html){
      $('#detailContent').html(html);
    }).fail(() => $('#detailContent').html('<div class="text-danger">Gagal memuat data</div>'));
  });

  // 🔹 Paksa selesai
  $(document).on('click', '.btn-force-finish', function(){
    const id = $(this).data('id');
    Swal.fire({
      title: 'Paksa Selesaikan?',
      text: 'Ujian siswa ini akan diselesaikan secara paksa.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Ya, Selesaikan'
    }).then((r)=>{
      if(!r.isConfirmed) return;
      $.post("<?= site_url('admin/cbt/aktivitas/forceFinish') ?>/"+id, {'<?= csrf_token() ?>':'<?= csrf_hash() ?>'}, function(){
        Swal.fire('Berhasil','Ujian telah diselesaikan','success').then(()=>location.reload());
      });
    });
  });

  // 🔹 Tambah waktu
  $(document).on('click', '.btn-tambah-waktu', function(){
    const id = $(this).data('id');
    Swal.fire({
      title: 'Tambah waktu',
      input: 'number',
      inputLabel: 'Berapa menit tambahan?',
      showCancelButton: true,
      confirmButtonText: 'Tambah'
    }).then(res=>{
      if(!res.isConfirmed || !res.value) return;
      $.post("<?= site_url('admin/cbt/aktivitas/addTime') ?>/"+id, 
        {'minutes':res.value,'<?= csrf_token() ?>':'<?= csrf_hash() ?>'}, 
        ()=>Swal.fire('Berhasil','Waktu ditambahkan','success').then(()=>location.reload()));
    });
  });

  // 🔹 Reset ujian
  $(document).on('click', '.btn-reset', function(){
    const id = $(this).data('id');
    Swal.fire({
      title: 'Reset sesi ujian?',
      text: 'Siswa harus mengulang dari awal.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Ya, Reset'
    }).then((r)=>{
      if(!r.isConfirmed) return;
      $.post("<?= site_url('admin/cbt/aktivitas/resetSession') ?>/"+id, 
        {'<?= csrf_token() ?>':'<?= csrf_hash() ?>'}, 
        ()=>Swal.fire('Sesi direset','Siswa dapat mengulang ujian','success').then(()=>location.reload()));
    });
  });
});
</script>
<?= $this->endSection() ?>

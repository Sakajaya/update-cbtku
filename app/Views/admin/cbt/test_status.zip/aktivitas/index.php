<?= $this->extend('layouts/app') ?>
<?= $this->section('content') ?>

<div class="container-fluid">
  <div class="card shadow-sm mb-3">
    <div class="card-body d-flex align-items-center">
      <div class="me-3">
        <div class="icon bg-light rounded-circle p-3">
          <i class="bi bi-person-lines-fill fs-3 text-primary"></i>
        </div>
      </div>
      <div>
        <h5 class="mb-1">Aktivitas Ujian dan Analisis</h5>
        <p class="mb-0 text-muted">
          Halaman ini memuat analisis setiap ujian yang sudah diikuti oleh user. 
          Admin dapat memantau aktivitas ujian, mengunduh nilai, melihat analisis soal, 
          serta mencetak laporan jawaban siswa.
        </p>
      </div>
    </div>
  </div>

  <div class="card shadow-sm">
    <div class="card-body table-responsive">
      <table id="tableAktivitas" class="table table-bordered align-middle w-100">
        <thead class="table-success text-center">
          <tr>
            <th>No</th>
            <th>Kode Tes</th>
            <th>Mata Pelajaran</th>
            <th>Lihat Aktivitas</th>
            <th>Unduh Nilai</th>
            <th>Analisis Soal / Jawaban</th>
            <th>Laporan Jawaban</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($sessions as $i => $s): ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td><strong><?= esc($s['test_code']) ?></strong></td>
            <td><?= esc($s['subject_name']) ?></td>
            <td class="text-center">
              <div class="btn-group">
                <a href="<?= site_url('admin/cbt/aktivitas/detail/'.$s['test_id']) ?>" 
                   class="btn btn-danger btn-sm">
                  <i class="bi bi-eye"></i> Aktivitas
                </a>
                <button class="btn btn-warning btn-sm btn-belum-tes" 
                        data-id="<?= $s['test_id'] ?>" 
                        data-name="<?= esc($s['subject_name']) ?>">
                  <i class="bi bi-person-x"></i> Belum Tes
                </button>
              </div>
            </td>
            <td class="text-center">
              <button class="btn btn-primary btn-sm btn-unduh-nilai" 
                      data-id="<?= $s['test_id'] ?>" 
                      data-name="<?= esc($s['subject_name']) ?>">
                <i class="bi bi-download"></i> Unduh
              </button>
            </td>
            <td class="text-center">
              <div class="btn-group">
                <a href="<?= site_url('admin/cbt/aktivitas/analisis/'.$s['test_id']) ?>" 
                   class="btn btn-warning btn-sm">
                  <i class="bi bi-eye"></i> Lihat
                </a>
                <button 
                  class="btn btn-info btn-sm btn-analisis-download"
                  data-id="<?= $s['test_id'] ?>" 
                  data-name="<?= esc($s['subject_name']) ?>">
                  <i class="bi bi-download"></i> Unduh
                </button>

              </div>
            </td>
            <td class="text-center">
              <a href="<?= site_url('admin/cbt/laporan/'.$s['test_id']) ?>" 
                 class="btn btn-success btn-sm">
                <i class="bi bi-printer"></i> Laporan Jawaban Siswa
              </a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- ======================= MODALS ======================= -->

<!-- Modal Belum Tes -->
<div class="modal fade" id="modalBelumTes" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-warning">
        <h5 class="modal-title">Daftar Siswa Belum Tes</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div id="belumTesContent" class="text-center text-muted">
          Memuat data...
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal Unduh Nilai -->
<div class="modal fade" id="modalUnduhNilai" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title">Unduh Nilai</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <p>Pilih kelas untuk mengunduh nilai:</p>
        <form id="formUnduhNilai" method="get">
          <input type="hidden" name="test_id" id="nilaiTestId">
          <div class="mb-3">
            <label for="classSelect" class="form-label">Pilih Kelas:</label>
            <select id="classSelect" name="class" class="form-select">
              <option value="all">Semua Kelas</option>
              <?php foreach ($classes as $cls): ?>
                <option value="<?= esc($cls['id']) ?>"><?= esc($cls['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <button type="submit" class="btn btn-success w-100">
            <i class="bi bi-download"></i> Unduh Excel
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Modal Unduh Analisis -->
<div class="modal fade" id="modalUnduhAnalisis" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-info text-white">
        <h5 class="modal-title">Download Analisis Jawaban</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body text-center">
        <p>Anda bisa mengunduh semua analisis atau bisa mengunduh analisis pada tiap kelas!</p>
        <div class="d-flex justify-content-center gap-3 mb-3">
          <button id="btnAnalisisTotal" class="btn btn-success">
            <i class="bi bi-file-earmark-excel"></i> Total
          </button>
          <button id="btnAnalisisPerKelas" class="btn btn-primary">
            <i class="bi bi-file-earmark-excel"></i> Per Kelas
          </button>
        </div>

        <div id="analisisClassSection" class="d-none">
          <label class="form-label">Pilih Kelas</label>
          <select id="analisisClassSelect" class="form-select mb-3">
            <option value="">Pilih Kelas...</option>
            <?php foreach ($classes as $cls): ?>
              <option value="<?= esc($cls['id']) ?>"><?= esc($cls['name']) ?></option>
            <?php endforeach; ?>
          </select>
          <button id="btnDownloadAnalisisKelas" class="btn btn-success w-100">
            Unduh
          </button>
        </div>
      </div>
    </div>
  </div>
</div>


<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
$(function() {
  // === DataTable ===
  $('#tableAktivitas').DataTable({
    responsive: true,
    order: [],
    language: {
      search: "Cari:",
      lengthMenu: "Tampilkan _MENU_ data per halaman",
      zeroRecords: "Tidak ada data ditemukan",
      info: "Menampilkan _START_ - _END_ dari _TOTAL_ data",
      infoEmpty: "Tidak ada data tersedia"
    }
  });

  // === TOMBOL BELUM TES ===
  $(document).on('click', '.btn-belum-tes', function() {
    const id = $(this).data('id');
    const name = $(this).data('name');
    $('#modalBelumTes .modal-title').text('Siswa Belum Tes - ' + name);
    $('#belumTesContent').html('<div class="text-center text-muted">Memuat data...</div>');
    $('#modalBelumTes').modal('show');

    $.get('<?= site_url('admin/cbt/aktivitas/belumTes/') ?>' + id, function(html) {
      $('#belumTesContent').html(html);
    })
    .fail(function(xhr){
      $('#belumTesContent').html('<div class="alert alert-danger">Gagal memuat data.<br>'+xhr.status+' '+xhr.statusText+'</div>');
    });
      });

  // === TOMBOL UNDUH NILAI ===
  $(document).on('click', '.btn-unduh-nilai', function() {
    const id = $(this).data('id');
    const name = $(this).data('name');
    $('#nilaiTestId').val(id);
    $('#modalUnduhNilai .modal-title').text('Unduh Nilai - ' + name);
    $('#modalUnduhNilai').modal('show');
  });

  // === SUBMIT FORM UNDUH NILAI ===
  $('#formUnduhNilai').on('submit', function(e) {
    e.preventDefault();
    const id = $('#nilaiTestId').val();
    const kelas = $('#classSelect').val();
    window.location.href = `<?= site_url('admin/cbt/aktivitas/unduhNilai/') ?>${id}?class=${kelas}`;
  });
});

// === TOMBOL UNDUH ANALISIS ===
$(document).on('click', '.btn-analisis-download', function() {
  const id = $(this).data('id');
  const name = $(this).data('name');
  $('#modalUnduhAnalisis .modal-title').text('Download Analisis Jawaban - ' + name);
  $('#modalUnduhAnalisis').data('test-id', id);
  $('#analisisClassSection').addClass('d-none');
  $('#analisisClassSelect').val('');
  $('#modalUnduhAnalisis').modal('show');
});

// === TOMBOL TOTAL ===
$('#btnAnalisisTotal').on('click', function() {
  const id = $('#modalUnduhAnalisis').data('test-id');
  const url = `<?= site_url('admin/cbt/aktivitas/analisisjawaban/download/') ?>${id}?mode=total`;
  window.location.href = url;
});

// === TOMBOL PER KELAS ===
$('#btnAnalisisPerKelas').on('click', function() {
  $('#analisisClassSection').removeClass('d-none');
});

// === TOMBOL UNDUH (PER KELAS) ===
$('#btnDownloadAnalisisKelas').on('click', function() {
  const id = $('#modalUnduhAnalisis').data('test-id');
  const classId = $('#analisisClassSelect').val();
  if (!classId) {
    alert('Silakan pilih kelas terlebih dahulu.');
    return;
  }
  const url = `<?= site_url('admin/cbt/aktivitas/analisisjawaban/download/') ?>${id}?mode=kelas&class=${classId}`;
  window.location.href = url;
});


</script>
<?= $this->endSection() ?>
